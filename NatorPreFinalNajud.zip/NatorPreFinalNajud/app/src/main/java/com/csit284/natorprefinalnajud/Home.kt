package com.csit284.natorprefinalnajud

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.ImageButton

class Home : AppCompatActivity (){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btnRecommended: Button = findViewById(R.id.btnRecommended)
        btnRecommended.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
            finish()
        }

        val btnDistance: Button = findViewById(R.id.btnDistance)
        btnDistance.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
        }

        val btnPrice: Button = findViewById(R.id.btnPrice)
        btnPrice.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
        }


        val btnDeal: Button = findViewById(R.id.btnDeal)
        btnDeal.setOnClickListener {
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
        }

      val imgBtnHome: ImageButton = findViewById(R.id.imgBtnHome)
      imgBtnHome.setOnClickListener{
          val intent = Intent(this,Home::class.java)
          startActivity(intent)
      }


        val imgBtnProfile: ImageButton = findViewById(R.id.imgBtnProfile)
        imgBtnProfile.setOnClickListener{
            val intent = Intent(this,Profile::class.java)
            startActivity(intent)
        }


        val imgBtnLogOut: ImageButton = findViewById(R.id.imgBtnLogOut)
        imgBtnLogOut.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }
    }
}