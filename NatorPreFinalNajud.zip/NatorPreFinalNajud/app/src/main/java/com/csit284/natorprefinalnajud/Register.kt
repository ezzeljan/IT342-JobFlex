package com.csit284.natorprefinalnajud

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast
import com.csit284.natorprefinalnajud.databinding.ActivityRegisterBinding

public class Register : AppCompatActivity() {



    private lateinit var  binding: ActivityRegisterBinding
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_register)


        databaseHelper = DatabaseHelper(this)


        binding.btnRegister.setOnClickListener {
            val signupUsername = binding.signupUsername.text.toString()
            val signupPassword = binding.signupPassword.text.toString()

            registerDatabase(signupUsername,signupPassword)
        }


       binding.loginRedirect.setOnClickListener{
           val intent = Intent(this, Login::class.java)
           startActivity(intent)
           finish()
       }
//        val btnLogin: Button = findViewById(R.id.btnLogin)
//        btnLogin.setOnClickListener {
//            val intent = Intent(this, Login::class.java)
//            startActivity(intent)
//            finish()
//        }

//        val btnRegister: Button = findViewById(R.id.btnRegister)
//        btnRegister.setOnClickListener {
//            val intent = Intent(this, Home::class.java)
//            startActivity(intent)
//        }
    }
    private fun registerDatabase(username: String, password: String){
        val insertRowId = databaseHelper.insertUser(username,password)
        if(insertRowId != -1L){
            Toast.makeText(this,"Signup Successful",Toast.LENGTH_SHORT).show()
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
            finish()
        }
        else {
            Toast.makeText(this,"Signup Failed", Toast.LENGTH_SHORT).show()
        }
    }

}