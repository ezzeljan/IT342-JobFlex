package com.csit284.natorprefinalnajud

import android.content.Intent
import android.os.Bundle
import android.support.v4.content.ContextCompat.startActivity
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast
import com.csit284.natorprefinalnajud.databinding.ActivityLoginBinding

class Login : AppCompatActivity() {

    private lateinit var binding:ActivityLoginBinding
    private lateinit var databaseHelper: DatabaseHelper



        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityLoginBinding.inflate(layoutInflater)
            setContentView(binding.root)


            databaseHelper = DatabaseHelper(this)

            binding.btnLogin.setOnClickListener {
                val loginUsername = binding.loginUsername.text.toString()
                val loginPassword = binding.loginPassword.text.toString()
                loginDataBase(loginUsername,loginPassword)
            }
            binding.signupRedirect.setOnClickListener{
                val intent = Intent(this, Register::class.java)
                startActivity(intent)
                finish()
            }
        }
//            setContentView(R.layout.activity_login)

//            val btnLogin: Button = findViewById(R.id.btnLogin)
//            btnLogin.setOnClickListener {
//                val intent = Intent(this, Home::class.java)
//                startActivity(intent)
//                finish()
//            }
//
//            val btnRegister: Button = findViewById(R.id.btnRegister)
//            btnRegister.setOnClickListener {
//                val intent = Intent(this, Register::class.java)
//                startActivity(intent)
//            }

    private fun loginDataBase(username: String, password: String){
        val userExists = databaseHelper.readUser(username, password)
        if (userExists){
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
            finish()
        }else{
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show()

        }
    }
}