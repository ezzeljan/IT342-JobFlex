package com.csit284.natorprefinalnajud

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import android.support.v7.app.AppCompatActivity
import com.csit284.natorprefinalnajud.databinding.ActivityProfileBinding

class Profile : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    private lateinit var databaseHelper: DatabaseHelper
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseHelper = DatabaseHelper(this)

        val username = intent.getStringExtra("USERNAME") ?: ""
        loadUserProfile(username)

        binding.btnUpdate.setOnClickListener {
            val newUsername = binding.profileUsername.text.toString()
            val newPassword = binding.profilePassword.text.toString()
            if (userId != -1) {
                updateUser(userId, newUsername, newPassword)
            } else {
                saveUser(newUsername, newPassword)
            }
        }

        binding.btnDelete.setOnClickListener {
            deleteUser(userId)
        }
    }

    private fun loadUserProfile(username: String) {
        val user = databaseHelper.getUser(username)
        if (user != null) {
            userId = user.id
            binding.profileUsername.setText(user.username)
            binding.profilePassword.setText(user.password)
        } else {
            Toast.makeText(this, "User not found!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveUser(username: String, password: String) {
        val insertRowId = databaseHelper.insertUser(username, password)
        if (insertRowId != -1L) {
            Toast.makeText(this, "User Updated Successfully", Toast.LENGTH_SHORT).show()
            redirectToHome(username)
        } else {
            Toast.makeText(this, "User Creation Failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateUser(id: Int, username: String, password: String) {
        if (id == -1) {
            Toast.makeText(this, "User not found!", Toast.LENGTH_SHORT).show()
            return
        }
        val rowsAffected = databaseHelper.updateUser(id, username, password)
        if (rowsAffected > 0) {
            Toast.makeText(this, "User Updated Successfully", Toast.LENGTH_SHORT).show()
            redirectToHome(username) // Redirect after update
        } else {
            Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteUser(id: Int) {
        if (id == -1) {
            Toast.makeText(this, "User not found!", Toast.LENGTH_SHORT).show()
            return
        }
        val rowsDeleted = databaseHelper.deleteUser(id)
        if (rowsDeleted > 0) {
            Toast.makeText(this, "User Deleted Successfully", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(this, "Delete Failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun redirectToHome(username: String) {
        val intent = Intent(this, Home::class.java)
        intent.putExtra("USERNAME", username)  // Pass the updated username
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }
}
